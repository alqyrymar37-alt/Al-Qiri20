# AlQiri

AlQiri is a lightweight Android assistant that works without an API key or paid subscription.

## Included
- Offline/local assistant replies; no API key required.
- Manual save only: nothing is saved automatically.
- New page, saved-page switching, and delete.
- Copy and edit controls for every message.
- Internet search opens the browser without requiring a search API key.
- Unknown-number checker that only checks the phone's local contacts after permission is granted; no number is uploaded.
- GitHub Actions workflow that builds a debug APK.

## Important
This project intentionally has no cloud AI API key. The included assistant is an offline app shell with local responses. A real on-device LLM can be added later as an optional model/runtime without changing the app's no-key principle.

## GitHub
Upload the **contents of this ZIP** to the root of a new GitHub repository. Do not upload the ZIP as the only repository file.

The repository root must contain `settings.gradle.kts`, `build.gradle.kts`, `app/`, and `.github/workflows/build.yml`.

Then open **Actions → Build AlQiri APK → Run workflow**. The generated APK appears under the workflow's **Artifacts** section.
