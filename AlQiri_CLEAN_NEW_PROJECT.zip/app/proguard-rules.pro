# AlQiri release rules. No custom shrinking rules are required.
