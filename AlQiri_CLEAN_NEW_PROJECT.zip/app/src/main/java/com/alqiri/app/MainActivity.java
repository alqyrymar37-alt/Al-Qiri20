package com.alqiri.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int CONTACT_PERMISSION = 41;
    private SharedPreferences prefs;
    private LinearLayout messagesBox;
    private EditText input;
    private TextView pageLabel;
    private int page = 1;
    private final ArrayList<Message> messages = new ArrayList<>();

    private static class Message {
        final boolean user;
        final String text;
        Message(boolean user, String text) { this.user = user; this.text = text; }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("alqiri", MODE_PRIVATE);
        buildUi();
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String text, float size) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(getColor(android.R.color.white));
        v.setPadding(dp(4), dp(4), dp(4), dp(4));
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setAllCaps(false);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(getColor(R.color.bg));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), dp(6), dp(8), dp(2));
        TextView title = label("AlQiri", 22);
        title.setTextColor(getColor(R.color.accent));
        top.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1));
        pageLabel = label("صفحة 1", 13);
        pageLabel.setGravity(Gravity.CENTER);
        top.addView(pageLabel, new LinearLayout.LayoutParams(dp(75), dp(52)));
        root.addView(top);

        LinearLayout tools = new LinearLayout(this);
        tools.setPadding(dp(6), 0, dp(6), dp(4));
        Button newBtn = button("＋ جديد");
        Button saveBtn = button("حفظ");
        Button pagesBtn = button("الصفحات");
        Button deleteBtn = button("حذف");
        Button searchBtn = button("بحث");
        Button numberBtn = button("رقم مجهول");
        tools.addView(newBtn, weightParams());
        tools.addView(saveBtn, weightParams());
        tools.addView(pagesBtn, weightParams());
        tools.addView(deleteBtn, weightParams());
        tools.addView(searchBtn, weightParams());
        tools.addView(numberBtn, weightParams());
        root.addView(tools);

        newBtn.setOnClickListener(v -> newPage());
        saveBtn.setOnClickListener(v -> savePage());
        pagesBtn.setOnClickListener(v -> showPages());
        deleteBtn.setOnClickListener(v -> deletePage());
        searchBtn.setOnClickListener(v -> webSearch());
        numberBtn.setOnClickListener(v -> showNumberChecker());

        ScrollView scroll = new ScrollView(this);
        messagesBox = new LinearLayout(this);
        messagesBox.setOrientation(LinearLayout.VERTICAL);
        messagesBox.setPadding(dp(10), dp(8), dp(10), dp(8));
        scroll.addView(messagesBox);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout composer = new LinearLayout(this);
        composer.setPadding(dp(8), dp(5), dp(8), dp(8));
        input = new EditText(this);
        input.setHint("اكتب رسالتك…");
        input.setTextColor(getColor(android.R.color.white));
        input.setHintTextColor(getColor(R.color.muted));
        input.setGravity(Gravity.TOP | Gravity.RIGHT);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        composer.addView(input, new LinearLayout.LayoutParams(0, dp(60), 1));
        Button send = button("إرسال");
        composer.addView(send, new LinearLayout.LayoutParams(dp(82), dp(60)));
        root.addView(composer);
        send.setOnClickListener(v -> sendMessage());

        setContentView(root);
        render();
    }

    private LinearLayout.LayoutParams weightParams() {
        return new LinearLayout.LayoutParams(0, dp(48), 1);
    }

    private void sendMessage() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        addMessage(true, text);
        input.setText("");
        addMessage(false, localReply(text));
    }

    private String localReply(String q) {
        String s = q.toLowerCase();
        if (s.contains("مرحبا") || s.contains("السلام") || s.contains("اهلا") || s.contains("أهلا"))
            return "مرحبًا! أنا AlQiri. أعمل محليًا بدون مفتاح API. اكتب سؤالك وسأحاول مساعدتك.";
        if (s.contains("من أنت") || s.contains("من انت"))
            return "أنا AlQiri، مساعد محلي داخل التطبيق. لا أحتاج إلى اشتراك أو مفتاح API، ويمكنك حفظ المحادثة يدويًا فقط.";
        if (s.contains("مساعدة") || s.contains("كيف"))
            return "يمكنك إنشاء صفحة جديدة، حفظ الصفحة يدويًا، نسخ أو تعديل أي رسالة، البحث عبر الإنترنت، وفحص رقم لمعرفة هل هو محفوظ في جهات الاتصال.";
        if (s.contains("شكرا") || s.contains("شكرًا")) return "العفو!";
        return "فهمت سؤالك: «" + q + "»\n\nهذه النسخة تعمل محليًا بدون API. للبحث عن معلومات حديثة اضغط زر «بحث»، وسأفتح البحث على الإنترنت.";
    }

    private void addMessage(boolean user, String text) {
        messages.add(new Message(user, text));
        render();
    }

    private void render() {
        if (messagesBox == null) return;
        messagesBox.removeAllViews();
        pageLabel.setText("صفحة " + page);
        if (messages.isEmpty()) {
            TextView welcome = label("محادثة جديدة\nلا يتم الحفظ تلقائيًا. اضغط «حفظ» عندما تريد الاحتفاظ بالصفحة.", 16);
            welcome.setTextColor(getColor(R.color.muted));
            welcome.setGravity(Gravity.CENTER);
            welcome.setPadding(dp(20), dp(40), dp(20), dp(40));
            messagesBox.addView(welcome);
            return;
        }
        for (int i = 0; i < messages.size(); i++) addMessageView(i, messages.get(i));
    }

    private void addMessageView(int index, Message m) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(8), dp(10), dp(8));
        card.setBackgroundColor(getColor(m.user ? R.color.panel2 : R.color.panel));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, dp(4), 0, dp(4));
        messagesBox.addView(card, cp);

        TextView who = label(m.user ? "أنت" : "AlQiri", 12);
        who.setTextColor(getColor(R.color.accent));
        card.addView(who);

        TextView text = label(m.text, 16);
        text.setTextIsSelectable(true);
        text.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        text.setPadding(0, dp(4), 0, dp(8));
        card.addView(text);

        LinearLayout actions = new LinearLayout(this);
        Button copy = button("نسخ");
        Button edit = button("تعديل");
        actions.addView(copy, weightParams());
        actions.addView(edit, weightParams());
        card.addView(actions);
        copy.setOnClickListener(v -> copyText(m.text));
        edit.setOnClickListener(v -> { input.setText(m.text); input.setSelection(input.length()); input.requestFocus(); });
    }

    private void copyText(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("AlQiri", text));
        Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show();
    }

    private void newPage() {
        page++;
        messages.clear();
        render();
    }

    private String pageKey(int p) { return "page_" + p; }

    private void savePage() {
        StringBuilder b = new StringBuilder();
        for (Message m : messages) {
            b.append(m.user ? "U" : "A").append("\t").append(m.text.replace("\\", "\\\\").replace("\n", "\\n")).append("\n");
        }
        prefs.edit().putString(pageKey(page), b.toString()).apply();
        Toast.makeText(this, "تم حفظ صفحة " + page + " يدويًا", Toast.LENGTH_SHORT).show();
    }

    private void loadPage(int p) {
        String raw = prefs.getString(pageKey(p), null);
        if (raw == null) {
            Toast.makeText(this, "لا توجد صفحة محفوظة", Toast.LENGTH_SHORT).show();
            return;
        }
        page = p;
        messages.clear();
        for (String line : raw.split("\\n", -1)) {
            if (line.length() < 2 || line.charAt(1) != '\t') continue;
            String text = line.substring(2).replace("\\n", "\n").replace("\\\\", "\\");
            messages.add(new Message(line.charAt(0) == 'U', text));
        }
        render();
    }

    private void deletePage() {
        prefs.edit().remove(pageKey(page)).apply();
        messages.clear();
        render();
        Toast.makeText(this, "تم حذف الصفحة المحفوظة", Toast.LENGTH_SHORT).show();
    }

    private void showPages() {
        ArrayList<String> labels = new ArrayList<>();
        ArrayList<Integer> ids = new ArrayList<>();
        for (int i = 1; i <= 50; i++) {
            if (prefs.contains(pageKey(i))) { labels.add("صفحة " + i); ids.add(i); }
        }
        if (labels.isEmpty()) {
            Toast.makeText(this, "لا توجد صفحات محفوظة بعد", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] arr = labels.toArray(new String[0]);
        new android.app.AlertDialog.Builder(this)
                .setTitle("الصفحات المحفوظة")
                .setItems(arr, (d, which) -> loadPage(ids.get(which)))
                .setNegativeButton("إغلاق", null)
                .show();
    }

    private void webSearch() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) q = "AlQiri AI";
        try {
            String url = "https://www.google.com/search?q=" + URLEncoder.encode(q, StandardCharsets.UTF_8.name());
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح البحث", Toast.LENGTH_SHORT).show();
        }
    }

    private void showNumberChecker() {
        final EditText number = new EditText(this);
        number.setHint("مثال: +9677xxxxxxxx");
        number.setInputType(InputType.TYPE_CLASS_PHONE);
        new android.app.AlertDialog.Builder(this)
                .setTitle("فحص رقم مجهول")
                .setMessage("سيتم فحص الرقم داخل جهات اتصال هاتفك فقط. لا يتم إرسال الرقم إلى أي خادم.")
                .setView(number)
                .setPositiveButton("فحص", (d, w) -> checkNumber(number.getText().toString().trim()))
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void checkNumber(String number) {
        if (number.isEmpty()) return;
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, CONTACT_PERMISSION);
            Toast.makeText(this, "اسمح بجهات الاتصال ثم أعد الفحص", Toast.LENGTH_LONG).show();
            return;
        }
        boolean known = false;
        Cursor c = null;
        try {
            Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number));
            c = getContentResolver().query(uri, new String[]{ContactsContract.PhoneLookup._ID}, null, null, null);
            known = c != null && c.moveToFirst();
        } finally {
            if (c != null) c.close();
        }
        String result = known ? "الرقم موجود في جهات الاتصال." : "الرقم غير موجود في جهات الاتصال على هاتفك (قد يكون رقمًا مجهولًا).";
        new android.app.AlertDialog.Builder(this).setTitle("نتيجة الفحص").setMessage(result).setPositiveButton("حسنًا", null).show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CONTACT_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "تم السماح بجهات الاتصال. افتح فحص الرقم مرة أخرى.", Toast.LENGTH_SHORT).show();
    }
}
