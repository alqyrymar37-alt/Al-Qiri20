# Security Policy

## Reporting a vulnerability

Please do not publish exploitable security details in a public issue.

Until a dedicated security contact is configured, report suspected vulnerabilities privately to the repository maintainers through GitHub's private vulnerability reporting feature, if enabled.

Never include passwords, API keys, phone numbers, contact lists, call logs, or other private data in an issue.
