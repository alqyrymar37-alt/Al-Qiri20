# Code of Conduct

We are committed to a respectful, constructive, and inclusive open-source project.

Participants should:

- Be respectful and professional.
- Focus criticism on code and decisions, not people.
- Avoid harassment, threats, discrimination, and personal attacks.
- Protect private information.

Maintainers may remove content or restrict participation when necessary to keep the project constructive and safe.
